#include<stdio.h>

int a = 10;

void func(){
    a=a+1;
    printf("a=%d\n", a);
    
}