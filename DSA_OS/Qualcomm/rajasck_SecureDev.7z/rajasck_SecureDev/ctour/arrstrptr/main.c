#include <stdio.h>

int main(){
    char *str = "rajasck";
    char x[] = {'r','a','j','a','s','c','k','\0'};
    printf("str: %s\n", str);
    printf("x : %s\n",x);
    return 0;
}