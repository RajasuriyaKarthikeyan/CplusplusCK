


void rajasck(){

    int i = 10;

    goto end;

    i = i+2;

    end:
        i=i+21;

    return;
}